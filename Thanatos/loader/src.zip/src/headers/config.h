#pragma once

#define HTTP_SERVER "45.140.170.32"
#define HTTP_PORT 80

#define TFTP_SERVER "45.140.170.32"
